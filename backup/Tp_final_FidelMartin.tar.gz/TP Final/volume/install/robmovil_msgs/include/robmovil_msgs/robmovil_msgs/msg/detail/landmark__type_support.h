// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from robmovil_msgs:msg/Landmark.idl
// generated code does not contain a copyright notice

#ifndef ROBMOVIL_MSGS__MSG__DETAIL__LANDMARK__TYPE_SUPPORT_H_
#define ROBMOVIL_MSGS__MSG__DETAIL__LANDMARK__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "robmovil_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_robmovil_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  robmovil_msgs,
  msg,
  Landmark
)();

#ifdef __cplusplus
}
#endif

#endif  // ROBMOVIL_MSGS__MSG__DETAIL__LANDMARK__TYPE_SUPPORT_H_

// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from robmovil_msgs:msg/Trajectory.idl
// generated code does not contain a copyright notice

#ifndef ROBMOVIL_MSGS__MSG__DETAIL__TRAJECTORY__TRAITS_HPP_
#define ROBMOVIL_MSGS__MSG__DETAIL__TRAJECTORY__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "robmovil_msgs/msg/detail/trajectory__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'points'
#include "robmovil_msgs/msg/detail/trajectory_point__traits.hpp"

namespace robmovil_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Trajectory & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: points
  {
    if (msg.points.size() == 0) {
      out << "points: []";
    } else {
      out << "points: [";
      size_t pending_items = msg.points.size();
      for (auto item : msg.points) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Trajectory & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: points
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.points.size() == 0) {
      out << "points: []\n";
    } else {
      out << "points:\n";
      for (auto item : msg.points) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Trajectory & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace robmovil_msgs

namespace rosidl_generator_traits
{

[[deprecated("use robmovil_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const robmovil_msgs::msg::Trajectory & msg,
  std::ostream & out, size_t indentation = 0)
{
  robmovil_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use robmovil_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const robmovil_msgs::msg::Trajectory & msg)
{
  return robmovil_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<robmovil_msgs::msg::Trajectory>()
{
  return "robmovil_msgs::msg::Trajectory";
}

template<>
inline const char * name<robmovil_msgs::msg::Trajectory>()
{
  return "robmovil_msgs/msg/Trajectory";
}

template<>
struct has_fixed_size<robmovil_msgs::msg::Trajectory>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<robmovil_msgs::msg::Trajectory>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<robmovil_msgs::msg::Trajectory>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ROBMOVIL_MSGS__MSG__DETAIL__TRAJECTORY__TRAITS_HPP_
